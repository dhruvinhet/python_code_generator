import streamlit as st

# Define functions for basic arithmetic operations

def add(x, y):
    """Adds two numbers.

    Args:
        x (float): The first number.
        y (float): The second number.

    Returns:
        float: The sum of the two numbers.
    """
    return x + y


def subtract(x, y):
    """Subtracts one number from another.

    Args:
        x (float): The first number.
        y (float): The second number.

    Returns:
        float: The difference between the two numbers.
    """
    return x - y


def multiply(x, y):
    """Multiplies two numbers.

    Args:
        x (float): The first number.
        y (float): The second number.

    Returns:
        float: The product of the two numbers.
    """
    return x * y


def divide(x, y):
    """Divides one number by another.

    Args:
        x (float): The first number.
        y (float): The second number.

    Returns:
        float: The quotient of the two numbers, or an error message if dividing by zero.
    """
    if y == 0:
        return "Error! Division by zero."
    else:
        return x / y



def main():
    """Main function to run the Streamlit calculator application."""
    st.title("Simple Calculator")

    # Create input fields for numbers
    num1 = st.number_input("Enter first number", value=0.0)
    num2 = st.number_input("Enter second number", value=0.0)

    # Create a selectbox for choosing the operation
    operation = st.selectbox(
        "Select operation",
        ("Add", "Subtract", "Multiply", "Divide")
    )

    # Perform the calculation based on the selected operation
    if st.button("Calculate"):
        try:
            if operation == "Add":
                result = add(num1, num2)
            elif operation == "Subtract":
                result = subtract(num1, num2)
            elif operation == "Multiply":
                result = multiply(num1, num2)
            elif operation == "Divide":
                result = divide(num1, num2)
            else:
                result = "Invalid operation"

            # Display the result
            if isinstance(result, str):
                st.error(result)
            else:
                st.success(f"Result: {result}")
        except Exception as e:
            st.error(f"An error occurred: {e}")

# Run the main function if the script is executed
if __name__ == "__main__":
    main()