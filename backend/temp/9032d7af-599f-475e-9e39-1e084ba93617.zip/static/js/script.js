// script.js

document.addEventListener('DOMContentLoaded', function() {
    // Example: Fetch vehicle data (replace with actual API call)
    const vehicles = [
        { id: 1, name: 'Sedan', image: 'https://via.placeholder.com/300x200', description: 'A comfortable sedan for everyday use.' },
        { id: 2, name: 'SUV', image: 'https://via.placeholder.com/300x200', description: 'A spacious SUV for family adventures.' },
        { id: 3, name: 'Truck', image: 'https://via.placeholder.com/300x200', description: 'A rugged truck for heavy-duty tasks.' }
    ];

    // Display vehicles
    const vehicleList = document.querySelector('.vehicle-list');
    if (vehicleList) {
        vehicles.forEach(vehicle => {
            const vehicleItem = document.createElement('div');
            vehicleItem.classList.add('vehicle-item');
            vehicleItem.innerHTML = `
                <img src="${vehicle.image}" alt="${vehicle.name}">
                <h3>${vehicle.name}</h3>
                <p>${vehicle.description}</p>
                <button>Rent Now</button>
            `;
            vehicleList.appendChild(vehicleItem);
        });
    }

    // Example: Hero button click
    const heroButton = document.querySelector('#hero button');
    if (heroButton) {
        heroButton.addEventListener('click', function() {
            alert('Navigating to vehicle list...'); // Replace with actual navigation
        });
    }

    // Simple form validation example (add to relevant forms)
    /*
    const form = document.querySelector('form'); // Replace with your form selector
    if (form) {
        form.addEventListener('submit', function(event) {
            let isValid = true;
            const requiredFields = form.querySelectorAll('[required]');
            requiredFields.forEach(field => {
                if (!field.value) {
                    alert('Please fill in all required fields.');
                    isValid = false;
                    event.preventDefault(); // Prevent form submission
                    return;
                }
            });

            if (!isValid) return;

            // Form is valid, you can submit the data
            alert('Form submitted successfully!');
        });
    }
    */
});