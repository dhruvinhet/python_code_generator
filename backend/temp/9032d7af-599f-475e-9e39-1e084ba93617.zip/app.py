from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS
import os
from routes import api

# Initialize Flask application
app = Flask(__name__)

# Configure the database
basedir = os.path.abspath(os.path.dirname(__file__))
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + os.path.join(basedir, 'vehicle_rental.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False  # Disable modification tracking for performance
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'your_secret_key') # Set a secret key for session management, use environment variable for production

# Initialize SQLAlchemy
db = SQLAlchemy(app)

# Enable CORS for all routes
CORS(app)

# Import models to create them
from models import User, Vehicle, Booking

# Register the API blueprint
app.register_blueprint(api)

# Create database tables if they don't exist
with app.app_context():
    db.create_all()

# Basic route for testing
@app.route('/')
def hello_world():
    return 'Hello, World! The backend is running.'

# Run the application if this script is executed
if __name__ == '__main__':
    app.run(debug=True)
