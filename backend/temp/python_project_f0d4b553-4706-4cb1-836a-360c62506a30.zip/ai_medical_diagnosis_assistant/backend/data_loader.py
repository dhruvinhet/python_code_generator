import pandas as pd
import logging
import os

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

def load_data(filepath, file_type='csv'):
    """Loads data from various file formats.

    Args:
        filepath: Path to the data file.
        file_type: Type of the file ('csv', 'json', 'xlsx'). Defaults to 'csv'.

    Returns:
        pandas.DataFrame: The loaded data as a DataFrame, or None if an error occurs.
    """
    try:
        logging.info(f"Loading data from {filepath} (type: {file_type})")
        if file_type.lower() == 'csv':
            df = pd.read_csv(filepath)
        elif file_type.lower() == 'json':
            df = pd.read_json(filepath)
        elif file_type.lower() == 'xlsx':
            df = pd.read_excel(filepath)
        else:
            logging.error(f"Unsupported file type: {file_type}")
            return None
        logging.info(f"Data loaded successfully. Shape: {df.shape}")
        return df
    except FileNotFoundError:
        logging.error(f"File not found: {filepath}")
        return None
    except pd.errors.EmptyDataError:
        logging.error(f"Empty data file: {filepath}")
        return None
    except Exception as e:
        logging.exception(f"An error occurred while loading data: {e}")
        return None