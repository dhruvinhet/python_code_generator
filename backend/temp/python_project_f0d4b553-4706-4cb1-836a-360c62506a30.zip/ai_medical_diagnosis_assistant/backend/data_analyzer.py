import pandas as pd
import logging
import numpy as np

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

def analyze_data(df):
    """Analyzes the dataset and provides descriptive statistics.

    Args:
        df: pandas.DataFrame

    Returns:
        dict: A dictionary containing descriptive statistics.
    """
    try:
        logging.info("Analyzing data...")
        analysis = {}
        analysis['shape'] = df.shape
        analysis['dtypes'] = df.dtypes
        analysis['missing_values'] = df.isnull().sum()
        analysis['summary_stats'] = df.describe(include='all')
        analysis['value_counts'] = {}
        for col in df.columns:
            if df[col].dtype != np.number:
                analysis['value_counts'][col] = df[col].value_counts()
        logging.info("Data analysis completed.")
        return analysis
    except Exception as e:
        logging.exception(f"An error occurred during data analysis: {e}")
        return None