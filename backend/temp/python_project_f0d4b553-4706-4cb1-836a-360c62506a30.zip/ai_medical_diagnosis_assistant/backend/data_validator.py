import pandas as pd
import logging

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

def validate_data(df, schema):
    """Validates the DataFrame against a given schema.

    Args:
        df: pandas.DataFrame
        schema: A dictionary defining the expected data types and constraints.
               Example: {'col1': {'type': 'int', 'min': 0}, 'col2': {'type': 'str'}}

    Returns:
        dict: A dictionary containing validation results (passed: bool, errors: list).
    """
    validation_results = {'passed': True, 'errors': []}
    try:
        logging.info("Validating data...")
        for col, constraints in schema.items():
            if col not in df.columns:
                validation_results['errors'].append(f"Column '{col}' not found.")
                validation_results['passed'] = False
                continue
            if constraints['type'] == 'int' and not pd.api.types.is_integer_dtype(df[col]):
                validation_results['errors'].append(f"Column '{col}' is not of type int.")
                validation_results['passed'] = False
            elif constraints['type'] == 'float' and not pd.api.types.is_float_dtype(df[col]):
                validation_results['errors'].append(f"Column '{col}' is not of type float.")
                validation_results['passed'] = False
            elif constraints['type'] == 'str' and not pd.api.types.is_string_dtype(df[col]):
                validation_results['errors'].append(f"Column '{col}' is not of type str.")
                validation_results['passed'] = False
            if 'min' in constraints and df[col].min() < constraints['min']:
                validation_results['errors'].append(f"Column '{col}' has values below the minimum ({constraints['min']}).")
                validation_results['passed'] = False
            # Add more constraint checks as needed (e.g., max, unique values, etc.)
        logging.info(f"Data validation completed. Passed: {validation_results['passed']}")
        return validation_results
    except Exception as e:
        logging.exception(f"An error occurred during data validation: {e}")
        return {'passed': False, 'errors': [str(e)]}