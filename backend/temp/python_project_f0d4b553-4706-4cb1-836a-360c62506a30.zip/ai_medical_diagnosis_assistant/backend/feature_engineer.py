import pandas as pd
import logging
from sklearn.preprocessing import StandardScaler, OneHotEncoder

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

def engineer_features(df, numerical_cols=[], categorical_cols=[]):
    """Performs feature engineering on the given DataFrame.

    Args:
        df: pandas.DataFrame
        numerical_cols: List of numerical columns to scale.
        categorical_cols: List of categorical columns to one-hot encode.

    Returns:
        pandas.DataFrame: The DataFrame with engineered features.
    """
    try:
        logging.info("Performing feature engineering...")
        df_engineered = df.copy()
        if numerical_cols:
            scaler = StandardScaler()
            df_engineered[numerical_cols] = scaler.fit_transform(df_engineered[numerical_cols])
        if categorical_cols:
            encoder = OneHotEncoder(handle_unknown='ignore', sparse_output=False)
            encoded_data = encoder.fit_transform(df_engineered[categorical_cols])
            encoded_df = pd.DataFrame(encoded_data, columns=encoder.get_feature_names_out(categorical_cols))
            df_engineered = pd.concat([df_engineered.drop(categorical_cols, axis=1), encoded_df], axis=1)
        logging.info("Feature engineering completed.")
        return df_engineered
    except Exception as e:
        logging.exception(f"An error occurred during feature engineering: {e}")
        return None