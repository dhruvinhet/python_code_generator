import pandas as pd
import logging

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

def clean_data(df, missing_value_strategy='drop'):
    """Cleans the dataset by handling missing values.

    Args:
        df: pandas.DataFrame
        missing_value_strategy: Strategy for handling missing values ('drop', 'fill_mean', 'fill_median', 'fill_mode').
                              Defaults to 'drop'.

    Returns:
        tuple: A tuple containing the cleaned DataFrame and a report of cleaning operations.
    """
    report = {}
    try:
        logging.info(f"Cleaning data using strategy: {missing_value_strategy}")
        original_shape = df.shape
        if missing_value_strategy == 'drop':
            df = df.dropna()
        elif missing_value_strategy == 'fill_mean':
            for col in df.columns:
                if df[col].dtype == np.number:
                    df[col] = df[col].fillna(df[col].mean())
        elif missing_value_strategy == 'fill_median':
            for col in df.columns:
                if df[col].dtype == np.number:
                    df[col] = df[col].fillna(df[col].median())
        elif missing_value_strategy == 'fill_mode':
            for col in df.columns:
                df[col] = df[col].fillna(df[col].mode()[0])
        else:
            logging.warning(f"Unknown missing value strategy: {missing_value_strategy}. No action taken.")
        report['original_shape'] = original_shape
        report['cleaned_shape'] = df.shape
        report['missing_values_before'] = df.isnull().sum().to_dict()
        report['missing_values_after'] = df.isnull().sum().to_dict()
        logging.info(f"Data cleaning completed. Original shape: {original_shape}, Cleaned shape: {df.shape}")
        return df, report
    except Exception as e:
        logging.exception(f"An error occurred during data cleaning: {e}")
        return None, None